import { GoogleGenAI } from "@google/genai";

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.warn("API_KEY is not set. AI features will be disabled.");
    return null;
  }
  return new GoogleGenAI({ apiKey });
};

export const generateThankYouMessage = async (amount: number): Promise<string> => {
  const ai = getClient();
  
  // Fallback if no API key
  if (!ai) {
    return "Merci pour votre geste. Comme la fontaine qui se vide pour mieux se remplir, votre générosité est une source de bénédictions.";
  }

  try {
    const prompt = `
      Tu agis au nom de l'Assemblée Spirituelle Nationale des Bahá’ís de France.
      Contexte : Week-end du Fonds national (5, 6 et 7 décembre 2025).
      Un ami vient de faire une promesse de don anonyme de ${amount} euros.
      
      Éléments de référence tirés de la lettre de l'Assemblée (2 déc 2025) :
      1. Citation de Shoghi Effendi : "Chaque serviteur... a l'obligation sacrée de contribuer spontanément et généreusement".
      2. Analogie clé : "Nous devons être comme la fontaine ou la source qui se vide continuellement jusqu’à se tarir et qui est continuellement alimentée par un flux invisible."
      3. Histoires inspirantes (à utiliser subtilement si le montant est élevé ou symbolique) :
         - L'oncle Samad : Il a vendu son âne (son gagne-pain) pour donner 100 tumans. Dieu lui a rendu un âne et une mule. Thème : sacrifice et confiance.
         - Kate et Ivan : Ont donné l'argent des réparations de leur maison. Un ouragan a tout détruit ensuite, l'assurance a tout payé. Thème : "Mettez le fonds en priorité et Dieu s'occupera du reste."
         - La dame européenne : A donné ses économies de sécurité. Son mari a arrêté de boire grâce à la Foi. Thème : gratitude et vraie sécurité.

      Tâche : Rédige un message de remerciement (2 phrases maximum).
      Ton : Solennel, spirituel, chaleureux, encourageant le sacrifice et la joie.
      Ne signe pas. Ne dis pas "Je suis une IA".
      Utilise parfois l'analogie de la fontaine ou une référence discrète aux histoires si cela s'y prête.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "Que votre générosité soit la source d'une prospérité spirituelle infinie.";
  } catch (error) {
    console.error("Error generating message:", error);
    return "Votre contribution est précieuse pour l'avancement de la Foi. Merci de tout cœur.";
  }
};